import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aside-account',
  templateUrl: './aside-account.component.html',
  styleUrls: ['./aside-account.component.css']
})
export class AsideAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
